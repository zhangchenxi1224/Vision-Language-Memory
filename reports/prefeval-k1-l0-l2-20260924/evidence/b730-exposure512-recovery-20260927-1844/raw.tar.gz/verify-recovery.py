import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import time
import torch

root=Path('/inspire/ssd/project/exploration-topic/czxs26210936/runs/prefeval-b730-exposure512-20260927')
recovery=root/'recovery-20260927-1844'
before_state=json.loads((recovery/'recovery.json').read_text())
deadline=time.monotonic()+300
while (root/'train/resume.pt').stat().st_mtime <= (recovery/'resume-before.pt').stat().st_mtime:
    if time.monotonic()>=deadline:
        raise TimeoutError('No new full checkpoint yet; inspect the live trainer without restarting it')
    time.sleep(5)
with (root/'train/resume.pt').open('rb') as f:
    saved=torch.load(f,map_location='cpu',weights_only=False)
    f.seek(0)
    digest=hashlib.file_digest(f,'sha256').hexdigest()
step=saved['optimizer_step']
assert step>=58112 and saved['episode_cursor']==step*4, 'Wait for the next full checkpoint; do not restart'
assert len(saved['optimizer']['state'])==1075
assert {int(v['step']) for v in saved['optimizer']['state'].values()}=={step}
assert saved['manifest']==json.loads((root/'train/manifest.json').read_text())
assert saved['manifest']['steps']==93440 and saved['manifest']['snapshot_steps']==[46720,70080]

def rows(path):
    out=[]
    for line in path.read_text().splitlines():
        try: out.append(json.loads(line))
        except ValueError: pass
    return out

current=[r for r in rows(root/'train/optimization.jsonl') if r['step']<=step]
assert [r['step'] for r in current]==list(range(1,step+1))
before={r['step']:r for r in rows(recovery/'train/optimization.jsonl')}
tail_steps=list(range(57985,58034))
exact=0
for s in tail_steps:
    a,b=before[s],current[s-1]
    assert a['draws']==b['draws'] and a['grad_norm']==b['grad_norm'], f'Replay differs at {s}'
    exact+=1
archived=sorted((root/'train').glob('optimization-uncommitted-*.jsonl'))
assert any([r['step'] for r in rows(p)]==tail_steps for p in archived)
for p in archived:
    if [r['step'] for r in rows(p)]==tail_steps:
        shutil.copy2(p,recovery/p.name)
assert sorted(str(p.relative_to(root)) for p in (root/'readback').glob('*/summary.json'))==before_state['completed_summaries']
subprocess.check_call(['python3',str(root.parent.parent/'b730_observe_20260927.py')],stdout=subprocess.DEVNULL)
runtime=json.loads((root/'latest-runtime.json').read_text())
assert runtime['failure'] is None and runtime['complete'] is None
assert runtime['controller']['commit']=='656fdf029c4a7c05e53bccb75483a03cf62d5f54'
active=[p for p in runtime['processes'] if p['status']=='running']
assert len(active)==1 and active[0]['label']=='train'
for p in active:
    assert p['pid_present'] and p['actual_cmdline'].strip()==' '.join(p['command'])
    assert p['actual_cwd']==runtime['controller']['repo']
shutil.copy2(root/'latest-runtime.json',recovery/'runtime-after.json')
shutil.copy2(root/'train/manifest.json',recovery/'manifest-after.json')
shutil.copy2(root/'launch.log',recovery/'launch-after.log')
(recovery/'optimization-committed-after.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in current))
report=dict(time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),restored_from_step=57984,verified_new_checkpoint_step=step,optimizer_states=1075,all_optimizer_states_same_step=True,full_log_contiguous_unique=True,replayed_updates=49,replayed_loss_grad_and_draws_exact_updates=exact,max_replayed_mse_delta=0,uncommitted_tail_archived=True,completed_summaries_unchanged=7,resume_sha256=digest,fixed_final_step=93440)
(recovery/'recovery-verification.json').write_text(json.dumps(report,indent=2)+'\n')
shutil.copy2(__file__,recovery/'verify-recovery.py')
shutil.copy2(root.parent.parent/'b730_recover_20260927_1844.py',recovery/'recover.py')
archive=recovery/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(recovery.rglob('*')):
        if p.is_file() and p!=archive and p.suffix!='.pt':
            tar.add(p,arcname=str(p.relative_to(recovery)),recursive=False)
with archive.open('rb') as f:
    archive_hash=hashlib.file_digest(f,'sha256').hexdigest()
receipt=dict(archive=str(archive),sha256=archive_hash,bytes=archive.stat().st_size)
(recovery/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(verification=report,archive=receipt),indent=2))
