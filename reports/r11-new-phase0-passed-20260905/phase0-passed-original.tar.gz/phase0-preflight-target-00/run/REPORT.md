# R11_new Phase 1A 运行报告

> 本报告仅由本次运行的机器可读 summary、manifest 与落盘 artifact 复算生成。

## 运行身份

- 模式：`technical-preflight`
- Git commit：`2cde77ece6f020ab8c747d7c73e19dac4d8fba1b`
- Target index：`0`
- Target segment：`r5-f1-8015bf53a4067aaa7e882288`
- 固定 primary endpoint：`raw_x_T_step256`
- 训练对象：仅 `x_T_fp32`；DreamLite U-Net、condition encoder、VAE 与 Reader 全部冻结。

## 三层结论

| 层级 | 结果 | 可解释范围 |
| --- | --- | --- |
| 工程通过 | 通过 | 只表示冻结、梯度、四步轨迹、receipt、checkpoint、哈希和快照契约是否成立。 |
| 诊断通过 | 未评估：preflight 只执行一次 backward，不执行 optimizer step。 | Phase 1A 仅测试单 query 的 Frozen-DreamLite endpoint 可达性。 |
| 科学成功 | `false` | 未训练共享 writer，未测试 state-level、多 seed、held-out、因果控制或 rollout。 |

不得把 train loss 下降、非零梯度、preflight 通过或单 target reachability 表述为 Picture Memory 训练成功。

## 固定执行事实

- backward 次数：`1`
- optimizer steps：`0`
- DreamLite denoiser steps：`4`
- effective sigmas：`[0.4999999701976776, 0.375, 0.25, 0.1249999925494194]`
- Query-level reachability：未评估。

## 原始 artifact 索引

| 路径 | 字节数 | SHA-256 |
| --- | ---: | --- |
| `.r11_new_output_owner.json` | 137 | `f4f58ed8a9e3871503f52c42694b20c68d85d81667d8b78f7808647fed68a0fd` |
| `checkpoint_hashes/step-000.json` | 1443 | `95aa37c5b64eb73df21ea74f96bfc867ee6bb0da5c02b6489561e3e6e6b70d3e` |
| `checkpoints/step-000.pt` | 1839024 | `c8adee8572a0cbda51e3f4e20740673c0dfd95da3ecff43f87522428255ec9ac` |
| `condition/official_full_condition.pt` | 1323530 | `086116e54a9a848389234eb71b6c511841cf9e5f8e33efb5dba0e5c35022c516` |
| `environment.txt` | 5730 | `390d9d3bf5efef0388a24550257a8865cbd96ad4f359efdb2339d129eeb994f1` |
| `images/step-000.png` | 225507 | `aa3aa73276d70dec0b1fdc257b6175142e8e53ce4a4c6ad9e4605efae105d3a9` |
| `manifest.json` | 37610 | `5f86b28856785ae752263699f027e99ee43c049592c26d84f33925b34b512528` |
| `model_snapshot_verification_end.json` | 1489 | `b5d486dc90e44cf13ed6a43c3fce81161c954e2b9e20e2c1690454f21fdd8830` |
| `model_snapshot_verification_start.json` | 1473 | `73be08bf40f7d0a5ebefad733e8afdb79c65aa28f506d3810c1fbef9819f0749` |
| `r11_new_phase1a_summary.json` | 2407 | `e60e54820336bb06d57ade580682cfeb2d36a226f6b347409f33ddbe48b19381` |
| `runtime.json` | 409 | `628d089b1ce904717205cfc6835001eb8886e81e2daba0c7b265b8dae6115957` |
| `technical_preflight.json` | 2407 | `e60e54820336bb06d57ade580682cfeb2d36a226f6b347409f33ddbe48b19381` |
| `terminal.json` | 209 | `d0f0d3ada1f02dfccf47451e42b130e2a4e454215a79a924b4a35aa8bb0bb80c` |

## 结论边界

canonical R11 的 direct VAE-latent 8/8 不能替代本实验。本轮即使 query-level gate 通过，也只证明锁定协议下存在可读的完整 Frozen-DreamLite endpoint；`formal_success_gate` 始终为 `false`。
